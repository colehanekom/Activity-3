public class Main {
    public static void main(String[] args) {
        // Create a company
        Company company = new Company("Capaciti Company");

        // Create stores
        Store store1 = new Store("Store 1", "Location 1");
        Store store2 = new Store("Store 2", "Location 2");

        // Add stores to the company
        company.addStore(store1);
        company.addStore(store2);

        // Create products
        Product product1 = new Product("Product 1", 10, 5.99);
        Product product2 = new Product("Product 2", 5, 9.99);
        Product product3 = new Product("Product 3", 20, 2.99);

        // Add products to store1
        store1.addProduct(product1);
        store1.addProduct(product2);

        // Add products to store2
        store2.addProduct(product2);
        store2.addProduct(product3);

        // Example usage
        System.out.println("Company: " + company.getName());
        for (Store store : company.getStoreList()) {
            System.out.println("Store: " + store.getName());
            System.out.println("Location: " + store.getLocation());
            System.out.println("Products in " + store.getName() + ":");
            for (Product product : store.getProductList()) {
                System.out.println(" - " + product.getName());
                System.out.println("   Quantity: " + product.getQuantity());
                System.out.println("   Price: R" + product.getPrice());
            }
            System.out.println();
        }
    }
}
