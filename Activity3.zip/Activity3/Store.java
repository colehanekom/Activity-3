import java.util.List;
import java.util.ArrayList;
public class Store {
    private String name;
    private String location;
    private List<Product> productList;

    public Store(String name, String location) {
        this.name = name;
        this.location = location;
        this.productList = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public List<Product> getProductList() {
        return productList;
    }

    public void addProduct(Product product) {
        productList.add(product);
    }
}
